﻿using System;
using System.Runtime.InteropServices;

using System.IO;
using UnityEngine;


using System.Runtime.CompilerServices;



// references http://www.mono-project.com/Interop_with_Native_Libraries


namespace UnityEngine
{


    namespace PS4
    {

        namespace Engines
        {

     



            public class HandDetection
            {

                [DllImport("HandDetectionPlugin")]
                static extern int PrxHandDetectionInitialise();

                [DllImport("HandDetectionPlugin")]
                static extern int PrxHandDetectionShutdown();


                public static int Init()
                {
                    return PrxHandDetectionInitialise();
                }

                public static int Term()
                {
                    return PrxHandDetectionShutdown();
                }




            }



        }
    }

}