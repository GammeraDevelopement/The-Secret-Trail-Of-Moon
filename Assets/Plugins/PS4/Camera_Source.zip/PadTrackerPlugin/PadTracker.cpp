#include <camera.h>
#include <string.h>
#include "prx.h"
#include <vision/pad_tracker.h>
#include <libsysmodule.h>
#include <kernel.h>
#include <sce_atomic.h>



namespace UnityCamera
{

	int32_t onionSize,garlicSize;
	off_t onionPhysAddr;
	void* onionMem = NULL;
	off_t garlicPhysAddr;
	void* garlicMem = NULL;

	ScePthread m_thread_padtracker;
	SceKernelEqueue m_queue_padtracker;

	const int numQueueEntrys = 32;
	int64_t m_queuealloc_padtracker;

	bool m_active = false;


	const int MaxTrackedPads = 4;

	struct PadTrackingRequest
	{
		int64_t cameraimagehandle;
		int32_t padhandles[MaxTrackedPads];
	};

	PadTrackingRequest m_Requests[numQueueEntrys];
//	int m_queueIDs[numQueueEntrys];


	static void* padTrackerThread(void* ptr);
	PRX_EXPORT int PrxPadTrackerUpdate(int64_t cameraimagehandle, int32_t *handles);

	PRX_EXPORT int PrxPadTrackerCalibrate(void)
	{
		if (m_active == false) return -1;
		return scePadTrackerCalibrate();
	}


	PRX_EXPORT int PrxPadTrackerInitialise(void)
	{

		if (m_active == true) return -1;
		m_active = false;


		int result = sceSysmoduleLoadModule(SCE_SYSMODULE_PAD_TRACKER);
		if (result != SCE_OK) { return result; }
		
		int32_t memalign = 16*1024;
		int memprot = SCE_KERNEL_PROT_CPU_READ|SCE_KERNEL_PROT_CPU_WRITE|SCE_KERNEL_PROT_GPU_READ|SCE_KERNEL_PROT_GPU_ALL;
		
		result = scePadTrackerGetWorkingMemorySize(&onionSize, &garlicSize);
		if (result != SCE_OK) { return result; }

		// allocate the memory

		result = sceKernelAllocateDirectMemory(0,SCE_KERNEL_MAIN_DMEM_SIZE, onionSize, memalign, SCE_KERNEL_WB_ONION,&onionPhysAddr);
		if (result != SCE_OK) { return result; }
		result = sceKernelMapDirectMemory( &onionMem, onionSize,memprot, 0,onionPhysAddr, memalign);
		if (result != SCE_OK) { return result; }

		result = sceKernelAllocateDirectMemory(0,SCE_KERNEL_MAIN_DMEM_SIZE, garlicSize, memalign, SCE_KERNEL_WC_GARLIC,&garlicPhysAddr);
		if (result != SCE_OK) { return result; }
		result = sceKernelMapDirectMemory( &garlicMem, garlicSize,memprot, 0,garlicPhysAddr, memalign);
		if (result != SCE_OK) { return result; }

		result = scePadTrackerInit(onionMem,garlicMem,4,3);
		if (result != SCE_OK) { return result; }


		result = sceKernelCreateEqueue(&m_queue_padtracker,"PadTrackerQueue");
		if (result<0)
		{
			printf("error during sceKernelCreateEqueue: 0x%x\n",result);
			return result;
		}

		ScePthreadAttr attr;
		scePthreadAttrInit(&attr);
		scePthreadAttrSetinheritsched(&attr, SCE_PTHREAD_EXPLICIT_SCHED);
		scePthreadAttrSetaffinity(&attr, 0x3f);	// 0x3f = all cores
		result = scePthreadCreate(&m_thread_padtracker, &attr, padTrackerThread, NULL, "PadTrackerThread");
        if (0 > result) 
		{
            printf("scePthreadCreate() failed\n");
			return result;
        }

		scePthreadAttrDestroy(&attr);

		SceKernelSchedParam  schedparam;
		int policy;
		scePthreadGetschedparam(m_thread_padtracker, &policy, &schedparam);
		printf("policy:%d prio:%d\n",policy, schedparam.sched_priority);

		schedparam.sched_priority = 700+1;

		scePthreadSetschedparam(m_thread_padtracker, policy, &schedparam);

		for (int id=0;id<numQueueEntrys; id++)
		{
			result = sceKernelAddUserEvent(m_queue_padtracker, id);
			if (result<0)
			{
				printf("error during sceKernelAddUserEvent: 0x%x\n",result);
				return result;
			}


		}
		m_queuealloc_padtracker=-1;

		m_active = true;

		return result;
	}


	static void* padTrackerThread(void* ptr)
	{
		int res;
		int num = 2;
		SceKernelEvent ev[num];
		while(1)
		{
			//if(s_GameEnd)
			//	break;

			int out = 0;
			res = sceKernelWaitEqueue(m_queue_padtracker,ev,num,&out,NULL);
			if (res<0)
			{
				printf("padTrackerThread queue returned with error 0x%x\n",res);
				break;
			}

			for (int evnt=0;evnt<out;evnt++)
			{
				SceKernelEvent *curEvent = &ev[evnt];
				int filter = sceKernelGetEventFilter(curEvent);
				if (filter !=  SCE_KERNEL_EVFILT_USER) continue;

				PadTrackingRequest *ptreq = (PadTrackingRequest *)sceKernelGetEventUserData(curEvent);
				int identry = sceKernelGetEventId(curEvent);

				PrxPadTrackerUpdate(ptreq->cameraimagehandle,ptreq->padhandles);

				// free the queue entry
				int64_t mask = (1<<identry);
				sceAtomicOr64(&m_queuealloc_padtracker, mask);	// set a bit to indicate that it is free

			}

		}
		scePthreadExit(NULL);
	}


	PRX_EXPORT int PrxPadTrackerQueueUpdate(int64_t cameraimagehandle, int32_t *handles)
	{
		int identry = -1;
		if (m_active == false) return -1;
		while(1)
		{
			identry = __builtin_ffsll(m_queuealloc_padtracker) -1;		// find first 1 bit
			if ((identry < 0)||(identry>=numQueueEntrys))
			{

#if _DEBUG
				printf("no space in PrxPadTrackerAddQueue queue\n");
#endif
				return -1;
			}
			
			int64_t mask = ~(1<<identry);
			int64_t oldvalue = sceAtomicAnd64(&m_queuealloc_padtracker, mask);	// clear a bit to indicate that it is in use
		
			if ((oldvalue & (1<<identry))!=0) break;	// confirm that the bit is available (might have just been taken by another thread)
			printf("bit taken ... attempting retry\n");	
		}


		m_Requests[identry].cameraimagehandle = cameraimagehandle;
		memcpy(m_Requests[identry].padhandles,handles,MaxTrackedPads * sizeof(int32_t) );
//		m_Requests[identry].padhandles = handles;

		int res = sceKernelTriggerUserEvent(m_queue_padtracker, identry, &m_Requests[identry]);
		if (res<0)
		{
			printf("sceKernelTriggerUserEvent failed 0x%x\n",res);
		}
		return res;
	}


	PRX_EXPORT int PrxPadTrackerUpdate(int64_t cameraimagehandle, int32_t *handles)
	{
		if (m_active == false) return -1;
//		printf("handles 0x%x 0x%x 0x%x 0x%x\n",handles[0],handles[1],handles[2],handles[3]);
		ScePadTrackerInput input;
		memset(&input,0,sizeof(input));

		if (handles!=NULL)
		{
			memcpy(&input.handles[0],handles,SCE_PAD_TRACKER_CONTROLLER_MAX*sizeof(int32_t));
		}
		// Set up image 1 for tracking
		SceCameraFrameData *imagedata = (SceCameraFrameData *)cameraimagehandle;
		input.images[0].data = NULL;	// do not perform tracking for image 0, only image 1
		input.images[1].exposure = imagedata->meta.exposureGain[1].exposure;
		input.images[1].gain = imagedata->meta.exposureGain[1].gain;
		input.images[1].data = imagedata->pFramePointerList[1][0];
		input.images[1].width = 1280;
		input.images[1].height = 800;
		if (input.images[1].data == NULL)
		{
			printf("null data from camera for pad tracking\n");
		}

		int result = scePadTrackerUpdate(input);
//		printf("scePadTrackerUpdate result: 0x%x\n",result);
		return result;
	}


	PRX_EXPORT int PrxPadTrackerReadState(int32_t handle, ScePadTrackerData *PadData)
	{
		if (m_active == false) return -1;

		int result = scePadTrackerReadState(handle, PadData);
		if (result != 0)
		{
			if (result==SCE_PAD_TRACKER_ERROR_INVALID_HANDLE)
			{
				printf("SCE_PAD_TRACKER_ERROR_INVALID_HANDLE ... do you have any pads initialised?\n");
			}
			else
			{
				printf("scePadTrackerReadState error:0x%x\n",result);
			}
		}
		return result;
	}

	
	PRX_EXPORT int PrxPadTrackerReadState2(int32_t handle, ScePadTrackerData *PadData)
	{
		if (m_active == false) return -1;

		int result = scePadTrackerReadState(handle, PadData);
		if (result != 0)
		{
			printf("scePadTrackerReadState error:0x%x\n",result);
		}
		return result;
	}

	PRX_EXPORT int PrxPadTrackerShutdown(void)
	{
		m_queuealloc_padtracker=0;		// clear the allocations ... so that no new ones can start
		int result;

		if (m_active == false) return -1;

		for (int id=0;id<numQueueEntrys; id++)
		{
			result = sceKernelDeleteUserEvent(m_queue_padtracker, id);
			if (result<0)
			{
				printf("error during sceKernelDeleteUserEvent: 0x%x\n",result);
			}
		}
		
		result = sceKernelDeleteEqueue(m_queue_padtracker);
		if (result<0)
		{
			printf("error during sceKernelDeleteEqueue: 0x%x\n",result);
		}

//return 0;
	//	result = scePthreadCancel(m_thread_padtracker);
		if (result<0)
		{
			printf("error during scePthreadCancel: 0x%x\n",result);
		}

	
		result = scePthreadJoin(m_thread_padtracker, NULL);
		if (result<0)
		{
			printf("error during scePthreadJoin: 0x%x\n",result);
		}




		int errcode = SCE_OK;
		result = scePadTrackerTerm();
		if (result != SCE_OK) 
		{
			printf("scePadTrackTerm failed\n");
			errcode = result;
		}
		

		result = sceKernelReleaseDirectMemory( onionPhysAddr, onionSize );
		if (result != SCE_OK) 
		{
			printf("sceKernelReleaseDirectMemory (onion) failed\n");
			errcode = result;
		
		}
		onionPhysAddr=0;
		onionSize=0;

		result = sceKernelReleaseDirectMemory( garlicPhysAddr, garlicSize );
		if (result != SCE_OK) 
		{
			printf("sceKernelReleaseDirectMemory (garlic) failed\n");
			errcode = result;
		}
		garlicPhysAddr=0;
		garlicSize=0;


		result = sceSysmoduleUnloadModule(SCE_SYSMODULE_PAD_TRACKER);
		if (result != SCE_OK) 
		{
			printf("sceSysmoduleUnloadModule (SCE_SYSMODULE_PAD_TRACKER) failed\n");
			errcode = result;
		}

		m_active = false;

		return errcode;
	}



}