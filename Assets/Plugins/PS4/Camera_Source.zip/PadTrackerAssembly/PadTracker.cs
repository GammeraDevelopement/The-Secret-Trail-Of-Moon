﻿using System;
using System.Runtime.InteropServices;

using System.IO;
using UnityEngine;


using System.Runtime.CompilerServices;



// references http://www.mono-project.com/Interop_with_Native_Libraries


namespace UnityEngine
{


   namespace PS4
    {

        namespace Engines
        {

            public enum ScePadTrackerStatus
            {
                SCE_PAD_TRACKER_TRACKING = 0,
                SCE_PAD_TRACKER_NOT_TRACKING = 1,
                SCE_PAD_TRACKER_ROOM_CONFLICT = 2,
                SCE_PAD_TRACKER_CALIBRATING = 3
            };

            [StructLayout(LayoutKind.Sequential, Pack = 0)]
            public struct ScePadTrackerImageCoordinates
            {
                public ScePadTrackerStatus status;
                public float x;
                public float y;
            };

            [StructLayout(LayoutKind.Sequential, Pack = 0)]
            public struct ScePadTrackerDataOLD
            {
                public ScePadTrackerStatus imageCoordinate0_status;
                public float imageCoordinate0_x;
                public float imageCoordinate0_y;

                public ScePadTrackerStatus imageCoordinate1_status;
                public float imageCoordinate1_x;
                public float imageCoordinate1_y;

            };


            [StructLayout(LayoutKind.Sequential, Pack = 0), Serializable]
            public struct ScePadTrackerData
            {


                // seems like this marshal correctly builds stack arrays, and allows you to pass the class to the native code and it appears as a pointer
                [MarshalAs(UnmanagedType.ByValArray, ArraySubType = UnmanagedType.SysUInt, SizeConst = 4 * 2)]
                public ScePadTrackerImageCoordinates[] imageCoordinates;
            };



            public class PadTracker
            {

                [DllImport("PadTrackerPlugin")]
                static extern int PrxPadTrackerInitialise();


                [DllImport("PadTrackerPlugin")]
                static extern int PrxPadTrackerShutdown();


                [DllImport("PadTrackerPlugin")]
                static extern int PrxPadTrackerCalibrate();


                [DllImport("PadTrackerPlugin")]
                static extern int PrxPadTrackerUpdate(UInt64 cameraFrameHandle, int[] controllerHandles);

                [DllImport("PadTrackerPlugin")]
                static extern int PrxPadTrackerQueueUpdate(UInt64 cameraFrameHandle, int[] controllerHandles);


                [DllImport("PadTrackerPlugin")]
                static extern int PrxPadTrackerReadState(int handle, out ScePadTrackerData data);

                [DllImport("PadTrackerPlugin")]
                static extern int PrxPadTrackerReadState(int handle, IntPtr ptr);

                public static int Init()
                {
                    return PrxPadTrackerInitialise();
                }

                public static int Term()
                {
                    return PrxPadTrackerShutdown();
                }

                public static int Calibrate()
                {
                    return PrxPadTrackerCalibrate();
                }

                public static int QueueUpdate(UInt64 cameraFrameHandle, int[] controllerHandles)
                {
                    return PrxPadTrackerQueueUpdate(cameraFrameHandle, controllerHandles);
                }

                public static int Update(UInt64 cameraFrameHandle, int[] controllerHandles)
                {
                    return PrxPadTrackerUpdate(cameraFrameHandle, controllerHandles);
                }

                // the data is output only
                // example of how to create a writeonly structure that contains an array of structures
                public static int ReadState(int controllerhandle, out ScePadTrackerData data)
                {
                    IntPtr unmanagedAddr = Marshal.AllocHGlobal(6 * 4);

                    data = new ScePadTrackerData();
                    data.imageCoordinates = new ScePadTrackerImageCoordinates[2];
                    float[] tempfloats = new float[3 * 2];

                    int result = PrxPadTrackerReadState(controllerhandle, unmanagedAddr);

                    // copy the whole set of data into an array of floats
                    Marshal.Copy(unmanagedAddr, tempfloats, 0, 6);


                    data.imageCoordinates[0].status = (ScePadTrackerStatus)Marshal.ReadInt32(unmanagedAddr, 0);
                    data.imageCoordinates[0].x = tempfloats[1];
                    data.imageCoordinates[0].y = tempfloats[2];

                    data.imageCoordinates[1].status = (ScePadTrackerStatus)Marshal.ReadInt32(unmanagedAddr, 12);
                    data.imageCoordinates[1].x = tempfloats[4];
                    data.imageCoordinates[1].y = tempfloats[5];

                    Marshal.FreeHGlobal(unmanagedAddr);
                    return result;
                }

            

            }



        }
   }

}