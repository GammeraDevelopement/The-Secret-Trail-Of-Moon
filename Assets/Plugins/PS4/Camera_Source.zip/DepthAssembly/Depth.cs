﻿using System;
using System.Runtime.InteropServices;

using System.IO;
using UnityEngine;


using System.Runtime.CompilerServices;



// references http://www.mono-project.com/Interop_with_Native_Libraries


namespace UnityEngine
{


    namespace PS4
    {

        namespace Engines
        {

            public enum SceDepthTrackingState
            {
                SCE_DEPTH_TRACKING_STATE_NG = -1,
                SCE_DEPTH_TRACKING_STATE_NOERR = 0,
                SCE_DEPTH_TRACKING_STATE_NO_DETECTION = 1
            };

            public enum SceDepthTrackingResultValidationState 
            {
                SCE_DEPTH_TRACKING_RESULT_VALIDATION_STATE_VALID = 0,
                SCE_DEPTH_TRACKING_RESULT_VALIDATION_STATE_INVALID = 1
            };

            [StructLayout(LayoutKind.Sequential, Pack = 0), Serializable]
            public struct SceDepthHeadCandidateTrackingResult
            {
                public float x;
                public float y;
                public float width;
                public float height;
                public float distanceFromCamera;
                public int id;
                public SceDepthTrackingState state;
            };

            [StructLayout(LayoutKind.Sequential, Pack = 0), Serializable]
            public struct SceDepthHandCandidateTrackingResult
            {
                public float x;
                public float y;
                public float distanceFromCamera;
                public int id;
                public SceDepthTrackingState state;
            };


            
            [StructLayout(LayoutKind.Sequential, Pack = 0), Serializable]
            public struct SceDepthTrackingResultValidationInformation
            {
                public int id;
                public SceDepthTrackingResultValidationState validationState;
            };

            public class Depth
            {

                [DllImport("DepthPlugin")]
                static extern int PrxDepthInitialise(bool HeadTracking, bool HandTracking);


                [DllImport("DepthPlugin")]
                static extern int PrxDepthShutdown();

                [DllImport("DepthPlugin")]
                static extern int PrxDepthUpdate(UInt64 cameraFrameHandle, bool PerformHeadTracking, bool PerformHandTracking);

                [DllImport("DepthPlugin")]
                static extern int PrxDepthQueueUpdate(UInt64 cameraFrameHandle, bool PerformHeadTracking, bool PerformHandTracking);

                [DllImport("DepthPlugin")]
                static extern int PrxDepthSetRoi(float sx, float sy, float sz, float sw);

                //[DllImport("DepthPlugin")]
                //static extern int PrxDepthHeadCandidateTrackerGetResult(out SceDepthHeadCandidateTrackingResult [] results, int numResults);

                [DllImport("DepthPlugin")]
                static extern int PrxDepthHeadCandidateTrackerGetResult(ref IntPtr results, int numResults);

                [DllImport("DepthPlugin")]
                static extern int PrxDepthHandCandidateTrackerGetResult(ref IntPtr results, int numResults);

                [DllImport("DepthPlugin")]
                static extern int PrxDepthHeadCandidateTrackerSetValidationInformation(IntPtr results, int numResults);

                [DllImport("DepthPlugin")]
                static extern IntPtr PrxDepthGetFrameIntPtr();


                [DllImport("DepthPlugin")]
                static extern int PrxDepthGetValidatedHeadResults(ref IntPtr results, int numResults);




                public static int Init(bool enableHeadTracking, bool enableHandTracking)
                {
                    return PrxDepthInitialise(enableHeadTracking, enableHandTracking);
                }

                public static int Term()
                {
                    return PrxDepthShutdown();
                }


                public static int QueueUpdate(UInt64 cameraFrameHandle, bool HeadTracking, bool HandTracking)
                {
                    return PrxDepthQueueUpdate(cameraFrameHandle, HeadTracking, HandTracking);
                }

                public static int Update(UInt64 cameraFrameHandle, bool HeadTracking, bool HandTracking)
                {
                    return PrxDepthUpdate(cameraFrameHandle, HeadTracking, HandTracking);
                }

                public static int SetRoi(float sx, float sy, float sz, float sw)
                {
                    return PrxDepthSetRoi(sx, sy, sz, sw);
                }

                public static IntPtr getFrameIntPtr()
                {
                    return PrxDepthGetFrameIntPtr();
                }


                // the data is output only
                // example of how to create a writeonly structure that contains an array of structures
                public static int HeadCandidateTrackerGetResult(out SceDepthHeadCandidateTrackingResult[] data, int maxnumresults)
                {
                    int result = 0;
                    int sizeofheadtracking = 7;
                    IntPtr unmanagedAddr = Marshal.AllocHGlobal(sizeofheadtracking * 4 * maxnumresults);
                    result = PrxDepthHeadCandidateTrackerGetResult(ref unmanagedAddr, maxnumresults);
                    if (result > 0)
                    {
                        data = new SceDepthHeadCandidateTrackingResult[result];
                        for (int i = 0; i < result; i++)
                        {
                            IntPtr ptr = new IntPtr(unmanagedAddr.ToInt64() + (28 * i));
                            data[i] = (SceDepthHeadCandidateTrackingResult)Marshal.PtrToStructure(ptr, typeof(SceDepthHeadCandidateTrackingResult));
                        }
                    }
                    else
                    {
                        data = new SceDepthHeadCandidateTrackingResult[0];
                    }

                    Marshal.FreeHGlobal(unmanagedAddr);
                    return result;
                }

                public static int GetValidatedHeadResults(out SceDepthHeadCandidateTrackingResult[] data, int maxnumresults)
                {
                    int result = 0;
                    int sizeofheadtracking = 7;
                    IntPtr unmanagedAddr = Marshal.AllocHGlobal(sizeofheadtracking * 4 * maxnumresults);
                    result = PrxDepthGetValidatedHeadResults(ref unmanagedAddr, maxnumresults);
                    if (result > 0)
                    {
                        data = new SceDepthHeadCandidateTrackingResult[result];
                        for (int i = 0; i < result; i++)
                        {
                            IntPtr ptr = new IntPtr(unmanagedAddr.ToInt64() + (sizeofheadtracking*4 * i));
                            data[i] = (SceDepthHeadCandidateTrackingResult)Marshal.PtrToStructure(ptr, typeof(SceDepthHeadCandidateTrackingResult));
                        }
                    }
                    else
                    {
                        data = new SceDepthHeadCandidateTrackingResult[0];
                    }
                    Marshal.FreeHGlobal(unmanagedAddr);
                    return result;
                }


                // the data is output only
                // example of how to create a writeonly structure that contains an array of structures
                public static int HandCandidateTrackerGetResult(out SceDepthHandCandidateTrackingResult[] data, int maxnumresults)
                {
                    int result = 0;
                    int sizeofhandtracking = 5;
                    IntPtr unmanagedAddr = Marshal.AllocHGlobal(sizeofhandtracking * 4 * maxnumresults);
                    result = PrxDepthHandCandidateTrackerGetResult(ref unmanagedAddr, maxnumresults);
                    if (result > 0)
                    {
                        data = new SceDepthHandCandidateTrackingResult[result];
                        for (int i = 0; i < result; i++)
                        {
                            IntPtr ptr = new IntPtr(unmanagedAddr.ToInt64() + (sizeofhandtracking*4 * i));
                            data[i] = (SceDepthHandCandidateTrackingResult)Marshal.PtrToStructure(ptr, typeof(SceDepthHandCandidateTrackingResult));
                        }
                    }
                    else
                    {
                        data = new SceDepthHandCandidateTrackingResult[0];
                    }

                    Marshal.FreeHGlobal(unmanagedAddr);
                    return result;
                }

                // the data is input only
                public static int HeadCandidateTrackerSetValidationInformation(SceDepthTrackingResultValidationInformation[] data)
                {
                    int numInfos = data.Length;
                    int sizeofvalidationdata = 2;
                    IntPtr unmanagedAddr = Marshal.AllocHGlobal(sizeofvalidationdata * 4 * numInfos);
                    Marshal.StructureToPtr(data, unmanagedAddr, false);
                    int result = PrxDepthHeadCandidateTrackerSetValidationInformation(unmanagedAddr, numInfos);
                    Marshal.FreeHGlobal(unmanagedAddr);
                    return result;
                }


       

            }



        }
    }

}