#include <camera.h>
#include <string.h>
#define PRX_EXPORT extern "C" __declspec (dllexport)
#include <stdlib.h>

#include <vision/depth.h>
#include <libsysmodule.h>
#include <kernel.h>
#include <sce_atomic.h>

#include <vector>

#include <perf.h>

namespace UnityCamera
{

	int32_t onionSize,garlicSize;
	off_t onionPhysAddr;
	void* onionMem = NULL;
	off_t garlicPhysAddr;
	void* garlicMem = NULL;
	void *systemMemory= NULL;

	ScePthread m_thread_padtracker;
	SceKernelEqueue m_queue_padtracker;

	const int numQueueEntrys = 8;
	int64_t m_queuealloc_padtracker;

	bool m_active = false;

	int m_handle = 0;
	void * m_dstBuffer = NULL;
	int m_dstBufferSize = 0;


//	std::vector <SceDepthHeadCandidateTrackingResult> s_TrackedHeads;
	const int s_MaxTrackedHeads = 4;
	SceDepthHeadCandidateTrackingResult s_TrackedHeads[s_MaxTrackedHeads];
	float depth_near = 0.65f;
	float depth_far = 1.50f;
	float sx = 0.25f;
	float ex = 0.75f;
	float sy = 0.15f;
	float ey = 0.65f;

	PRX_EXPORT int PrxDepthInitialise(bool enableHeadTracking, bool enableHandTracking)
	{
		if (m_active == true) return -1;
		m_active = false;

		int result = sceSysmoduleLoadModule(SCE_SYSMODULE_DEPTH);
		if (result != SCE_OK) { return result; }
		
		/* Input image format */
		SceDepthInputImageInformation imgInfo = {};
		imgInfo.width = 640;
		imgInfo.height = 400;
		imgInfo.pixelFormat = SCE_DEPTH_PIXEL_FORMAT_Y8;
		/* Library operation mode */
		SceDepthProcessingInformation processingInfo = {};
		processingInfo.width = 320;
		processingInfo.height = 200;
		processingInfo.executionMode = 0;
		processingInfo.updateMode = 0;
		if (enableHeadTracking==true)
		{
			processingInfo.updateMode |= SCE_DEPTH_UPDATEMODE_ENABLE_HEAD_CANDIDATE_TRACKING;
		}
		if (enableHandTracking==true)
		{
			processingInfo.updateMode |= SCE_DEPTH_UPDATEMODE_ENABLE_HAND_CANDIDATE_TRACKING;
		}
		processingInfo.cameraType = SCE_DEPTH_STEREO_CAMERA_TYPE_PLAYSTATION_CAMERA;
		/* Initialization parameters covering the above setting information */
		SceDepthInitializeParameter initParam = {};
		initParam.sizeofInitializeParameter = sizeof( SceDepthInitializeParameter );
		initParam.inputImageInformation = imgInfo;
		initParam.processingInformation = processingInfo;

		SceDepthQueryMemoryResult memoryUsage;
		result = sceDepthQueryMemory( &initParam, &memoryUsage );
		if ( result < 0 ) {
			printf("sceDepthQueryMemory failed 0x%x\n",result);
			return result;
			/* Error handling */
		}


		systemMemory = memalign( 256, memoryUsage.systemMemorySize ); 
//		void *systemSharedMemory = allocateSystemSharedMemoryAlign( 64 * 1024, memoryUsage.systemSharedMemorySize );
//		void *videoSharedMemory = allocateVideoSharedMemoryAlign( 64 * 1024, memoryUsage.videoSharedMemorySize );
		int  memalignsize = 64*1024;
		int memprot = SCE_KERNEL_PROT_CPU_READ|SCE_KERNEL_PROT_CPU_WRITE|SCE_KERNEL_PROT_GPU_READ|SCE_KERNEL_PROT_GPU_ALL;

		m_dstBufferSize = initParam.processingInformation.width/4 *
			initParam.processingInformation.height/4 *
            2;
		
		int garlicrequiredsize = memoryUsage.videoSharedMemorySize;
		int onionrequiredsize = memoryUsage.systemSharedMemorySize + m_dstBufferSize;		// allow cpu buffer to render depth buffer if required
			
		// round up to 16k
		onionrequiredsize+=((16*1024)-1);
		onionrequiredsize&=~((16*1024)-1);


		printf("onionrequiredsize  0x%x + 0x%x\n",memoryUsage.systemSharedMemorySize , m_dstBufferSize);

		result = sceKernelAllocateDirectMemory(0,SCE_KERNEL_MAIN_DMEM_SIZE, onionrequiredsize, memalignsize, SCE_KERNEL_WB_ONION,&onionPhysAddr);
		if (result != SCE_OK) 
		{ 
			printf("sceKernelAllocateDirectMemory failed 0x%x\n",result);
			return result; 
		}
		result = sceKernelMapDirectMemory( &onionMem, onionrequiredsize,memprot, 0,onionPhysAddr, memalignsize);
		if (result != SCE_OK) 
		{ 
			printf("sceKernelAllocateDirectMemory failed 0x%x\n",result);
			return result; 
		}
		void *systemSharedMemory = onionMem;

		result = sceKernelAllocateDirectMemory(0,SCE_KERNEL_MAIN_DMEM_SIZE, garlicrequiredsize, memalignsize, SCE_KERNEL_WC_GARLIC,&garlicPhysAddr);
		if (result != SCE_OK) { return result; }
		result = sceKernelMapDirectMemory( &garlicMem, garlicrequiredsize,memprot, 0,garlicPhysAddr, memalignsize);
		if (result != SCE_OK) { return result; }

		void *videoSharedMemory = garlicMem;


		m_dstBuffer = (void *)((char *)onionMem + memoryUsage.systemSharedMemorySize);

		printf("onionMem:0x%p m_dstBuffer:0x%p\n",onionMem, m_dstBuffer);


		SceDepthMemoryInformation memoryInfo;
		memset(&memoryInfo,0,sizeof(memoryInfo));
		memoryInfo.systemMemory = systemMemory;
		memoryInfo.systemMemorySize = memoryUsage.systemMemorySize;
		memoryInfo.videoSharedMemory = videoSharedMemory;
		memoryInfo.videoSharedMemorySize = memoryUsage.videoSharedMemorySize;
		memoryInfo.systemSharedMemory = systemSharedMemory;
		memoryInfo.systemSharedMemorySize = memoryUsage.systemSharedMemorySize;



		m_handle = sceDepthInitialize( &initParam, &memoryInfo );
		if( m_handle < 0 ) 
		{
			printf("sceDepthInitialize failed 0x%x\n",m_handle);
			return result;
			/* Error handling */
		}

		m_active = true;

		return result;
	}


	PRX_EXPORT int PrxDepthSetRoi(float sx, float sy, float sz, float sw)
	{
		return  sceDepthSetRoi(m_handle, sx, sy, sz, sw);
	}



	PRX_EXPORT int PrxDepthUpdate(int64_t cameraimagehandle, bool performHeadTracking, bool performHandTracking)
	{
		if (m_active == false) return -1;

		SceCameraFrameData *imagedata = (SceCameraFrameData *)cameraimagehandle;

		SceDepthUpdateParameter updateParam = {};
		updateParam.sizeofUpdateParameter = sizeof( SceDepthUpdateParameter );
		updateParam.image0 = imagedata->pFramePointerList[0][1];; // Pointer to image obtained from
														// channel 0
		updateParam.image1 = imagedata->pFramePointerList[1][1];; // Pointer to image obtained from
														// channel 1
		if (imagedata->meta.format[0][1] != SCE_CAMERA_SCALE_FORMAT_Y8)
		{
			printf("camera 0 level 1 does not contain Y8 data\n");
			return -1;
		}
		if (imagedata->meta.format[1][1] != SCE_CAMERA_SCALE_FORMAT_Y8)
		{
			printf("camera 1 level 1 does not contain Y8 data\n");
			return -1;
		}

		updateParam.updateMode = 0;
		if (performHeadTracking==true)
		{
			updateParam.updateMode |= SCE_DEPTH_UPDATEMODE_ENABLE_HEAD_CANDIDATE_TRACKING;
		}
		if (performHandTracking==true)
		{
			updateParam.updateMode |= SCE_DEPTH_UPDATEMODE_ENABLE_HAND_CANDIDATE_TRACKING;
		}

		updateParam.context = nullptr;

		// TODO: move this calibration elsewhere
		static bool checkedcalibration = false;
		if (checkedcalibration == false)
		{
			checkedcalibration = true;

			int result = sceDepthHasCalibrationData( m_handle );
			printf("sceDepthHasCalibrationData result:0x%x\n",result);

			if( result < 0 )
			{
				result = sceDepthLoadCalibrationData( m_handle );
				printf("sceDepthLoadCalibrationData result:0x%x\n",result);

			}
			if ( result != SCE_OK ) 
			{
				// Calibration data is not retained
			} else 
			{
				int result = sceDepthValidateCurrentCalibrationData( m_handle, &updateParam );
				printf("sceDepthValidateCurrentCalibrationData result:0x%x\n",result);


				if( result == SCE_DEPTH_ERROR_CALIBRATION_IS_NECESSARY ){
				// Prompt user to execute calibration
				}
			}
		}
		return sceDepthUpdate(m_handle, &updateParam);;
	}

	/*
		passing a block of memory via a IntPtr
		C# code:
			IntPtr unmanagedAddr = Marshal.AllocHGlobal(sizeofheadtracking * 4 * numresults);
			result = PrxDepthHeadCandidateTrackerGetResult(out unmanagedAddr, numresults);
	*/
	PRX_EXPORT int PrxDepthHeadCandidateTrackerGetResult(void **ppResults, int maxResults)
	{
		SceDepthHeadCandidateTrackingResult * results = (SceDepthHeadCandidateTrackingResult *)*ppResults;
		int result = sceDepthHeadCandidateTrackerGetResult(m_handle, results, maxResults);
//		printf("%d heads found!\n", result);
		return result;
	}

	PRX_EXPORT int PrxDepthHeadCandidateTrackerSetValidationInformation(void **ppInfo, int numInfos)
	{
		SceDepthTrackingResultValidationInformation * info = (SceDepthTrackingResultValidationInformation *)*ppInfo;
		int result = sceDepthHeadCandidateTrackerSetValidationInformation(m_handle, info, numInfos);
		return result;
	}




	PRX_EXPORT int PrxDepthHandCandidateTrackerGetResult(void **ppResults, int maxResults)
	{
		SceDepthHandCandidateTrackingResult * results = (SceDepthHandCandidateTrackingResult *)*ppResults;
		int result = sceDepthHandCandidateTrackerGetResult(m_handle, results, maxResults);
//		printf("%d hands found!\n", result);
		return result;
	}





	/*
		High level update ... retreives raw data, plus handles trivial detection
	*/
	PRX_EXPORT int PrxDepthGetValidatedHeadResults(void **ppResults, int MaxResults)
	{
		SceDepthHeadCandidateTrackingResult * results = (SceDepthHeadCandidateTrackingResult *)*ppResults;

		const int MaxRawHeadTracks=8;
		SceDepthHeadCandidateTrackingResult RawHeadTrackingData[MaxRawHeadTracks];
		SceDepthTrackingResultValidationInformation ValidationData[MaxRawHeadTracks];
		void * ResultPtr  = &RawHeadTrackingData;

		int numFoundRawHeads = PrxDepthHeadCandidateTrackerGetResult((void **)&ResultPtr, MaxRawHeadTracks);
	
		// go through array, removing all tracked heads not found in the raw results
		for (int i=0;i<s_MaxTrackedHeads;i++)
		{
			SceDepthHeadCandidateTrackingResult *Head = &s_TrackedHeads[i];
			int TrackedID = Head->id;
			if (TrackedID != -1)
			{
				bool FoundTracked=false;
				int j;
				for (j=0;j<numFoundRawHeads;j++) { if (RawHeadTrackingData[j].id == TrackedID) { FoundTracked=true; break; } }
				if (FoundTracked==false) 
				{
					Head->id = -1;		// remove from list
				}
				else
				{
					// update the data
					s_TrackedHeads[i] = RawHeadTrackingData[j];
				}
			}
		}
	
	
		// now go through raw results to see if they are good
		for (int j=0; j<numFoundRawHeads; j++)
		{
			int RawID = RawHeadTrackingData[j].id;

			bool FoundTracked=false;
			int EmptySlot = -1;
			for (int i=0;i<s_MaxTrackedHeads;i++)
			{
				SceDepthHeadCandidateTrackingResult *Head = &s_TrackedHeads[i];
				int TrackedID = Head->id;
				if (RawID == TrackedID) {FoundTracked=true;}
				if (TrackedID==-1 && EmptySlot==-1) { EmptySlot = i; }
			}

			if ((FoundTracked == false)&&(EmptySlot!=-1))	// if id is NOT in the tracked list
			{
				float dist =  RawHeadTrackingData[j].distanceFromCamera;
				if (dist < depth_near) continue;
				if (dist > depth_far) continue;
				float x =  RawHeadTrackingData[j].x;
				if (x< sx || x> ex ) continue;
				float y =  RawHeadTrackingData[j].y;
				if (y< sy || y> ey ) continue;

				s_TrackedHeads[EmptySlot] = RawHeadTrackingData[j];
			}
		}

		// count the number of tracked heads, and write out results
		int numTrackedHeads=0;
		for (int i=0;i<s_MaxTrackedHeads;i++)
		{
			SceDepthHeadCandidateTrackingResult *Head = &s_TrackedHeads[i];
			if (Head->id != -1)
			{
				results[numTrackedHeads]=*Head;
				ValidationData[numTrackedHeads].id = Head->id;
				ValidationData[numTrackedHeads].validationState =SCE_DEPTH_TRACKING_RESULT_VALIDATION_STATE_VALID;
				numTrackedHeads++;
			}
		}

		int result = sceDepthHeadCandidateTrackerSetValidationInformation(m_handle, ValidationData, numTrackedHeads);
		if (result<0)
		{
			printf("error calling sceDepthHeadCandidateTrackerSetValidationInformation 0x%x\n",result);
		}

		return numTrackedHeads;
	}





	PRX_EXPORT void * PrxDepthGetFrameIntPtr()
	{
		int result = sceDepthGetImage(m_handle, SCE_DEPTH_IMAGE_TYPE_DEPTH_16BIT, m_dstBuffer, m_dstBufferSize);
//		printf("getting depth image to 0x%p size:0x%x result:0x%x\n",m_dstBuffer, m_dstBufferSize, result);
		if (result < 0)
		{
			printf("error calling sceDepthGetImage 0x%x\n",result);
			return NULL;
		}

		return m_dstBuffer;
	}


	PRX_EXPORT int PrxDepthShutdown(void)
	{
		int result;
		m_queuealloc_padtracker=0;		// clear the allocations ... so that no new ones can start
		if (m_active == false) return -1;
		int errcode = SCE_OK;

		sceDepthTerminate(m_handle);


		result = sceSysmoduleUnloadModule(SCE_SYSMODULE_DEPTH);
		if (result != SCE_OK) 
		{
			printf("sceSysmoduleUnloadModule (SCE_SYSMODULE_DEPTH) failed\n");
			errcode = result;
		}

		free(systemMemory);
		systemMemory=NULL;

		result = sceKernelReleaseDirectMemory( onionPhysAddr, onionSize );
		if (result != SCE_OK) 
		{
			printf("sceKernelReleaseDirectMemory (onion) failed\n");
			errcode = result;
		
		}
		onionPhysAddr=0;
		onionSize=0;

		result = sceKernelReleaseDirectMemory( garlicPhysAddr, garlicSize );
		if (result != SCE_OK) 
		{
			printf("sceKernelReleaseDirectMemory (garlic) failed\n");
			errcode = result;
		}
		garlicPhysAddr=0;
		garlicSize=0;


		m_handle=-1;
		m_active = false;
		return errcode;
	}



}