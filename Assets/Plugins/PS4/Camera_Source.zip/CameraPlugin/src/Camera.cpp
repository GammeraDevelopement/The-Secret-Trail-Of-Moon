#include <camera.h>
#include <string.h>
#include <kernel.h>

#include "prx.h"

#define NDEBUG (1)	// disable tty spam

#if NDEBUG
#define UNITY_TRACE(...)
#define UNITY_TRACEIF(condition, ...)
#else
#define UNITY_TRACE(...)				printf(__VA_ARGS__)
#define UNITY_TRACEIF(condition, ...)	if (condition) printf(__VA_ARGS__)
#endif


namespace UnityCamera
{
	ScePthread m_thread_camera = 0;
	static  ScePthreadMutex s_thread_mutex;
	static int s_GameEnd = 0;
	static  int s_started = 0;
	static  int s_camera_handle = 0;
	static int s_lastretreivedbuffer = 0;

	const static int CAM_BUF_CNT = 16;
	static SceCameraFrameData s_camFrame[CAM_BUF_CNT];
	static int sCurCamBuf=0;

	static	SceKernelEventFlag s_event_flag[CAM_BUF_CNT];
	#define EVF_BIT_DRAW (0x00010000U)

	typedef int (*CAMERACALLBACK)(SceCameraFrameData *framedata);
	CAMERACALLBACK CameraFrameCallback = NULL;


	PRX_EXPORT int PrxCameraIsAttached(int index)
	{
		return sceCameraIsAttached(index);
	}

	PRX_EXPORT int PrxSetCameraFrameCallback(int64_t newcallback)
	{
		CameraFrameCallback = (CAMERACALLBACK) newcallback;
		return 0;
	}

	
	PRX_EXPORT int PrxCameraSetConfig(int32_t handle, SceCameraConfig *pConfig)
	{
#if(0)
		printf("PrxCameraSetConfig called sizeof(SceCameraConfigExtention)=%d\n",sizeof(SceCameraConfigExtention));
		printf("pConfig:0x%p\n",pConfig);
		printf(" SizeThis:0x%x\n",pConfig -> sizeThis);
		printf(" configType:0x%x\n",pConfig -> configType);
		printf(" configExtention[0].format:0x%p\n",&pConfig -> configExtention[0].format);
		printf(" configExtention[0].resolution:0x%p\n",&pConfig -> configExtention[0].resolution);
		printf(" configExtention[0].framerate:0x%p\n",&pConfig -> configExtention[0].framerate);
		printf(" configExtention[0].width:0x%p\n",&pConfig -> configExtention[0].width);
		printf(" configExtention[0].pBaseOption:0x%p\n",&pConfig -> configExtention[0].pBaseOption);


		printf(" configExtention[1]:0x%p\n",&pConfig -> configExtention[1].format);

		printf(" 0format:0x%x\n",pConfig -> configExtention[0].format);
		printf(" 1format:0x%x\n",pConfig -> configExtention[1].format);
#endif
		if (pConfig->sizeThis != sizeof(SceCameraConfig))
		{
			printf("sizeThis(0x%x) != sizeof(SceCameraConfig) (0x%x)\n",pConfig->sizeThis ,sizeof(SceCameraConfig));
		}
		int result = sceCameraSetConfig(handle, pConfig);
		return result;
	}


	PRX_EXPORT int PrxCameraOpen(SceUserServiceUserId userId, int32_t type, int32_t index, SceCameraOpenParameter *pParam)
	{
		return sceCameraOpen(userId, type, index, pParam);
	}

	PRX_EXPORT int PrxCameraStart(int32_t handle, SceCameraStartParameter  *pParam)
	{
		//printf("PrxCameraStart called handle:0x%x\n", handle);

		//printf("pConfig:0x%p\n",pParam);
		//printf(" SizeThis:0x%x\n",pParam -> sizeThis);
		//printf(" formatLevel[0]:*0x%p = 0x%x\n",&pParam -> formatLevel[0], pParam -> formatLevel[0]);
		//printf(" formatLevel[1]:*0x%p = 0x%x\n",&pParam -> formatLevel[1], pParam -> formatLevel[1]);


		if (pParam->sizeThis != sizeof(SceCameraStartParameter))
		{
			printf("sizeThis(0x%x) != sizeof(SceCameraStartParameter) (0x%x)\n",pParam->sizeThis ,sizeof(SceCameraStartParameter));
		}

		s_camera_handle = handle;
		int result = sceCameraStart(handle, pParam);
		if (result != 0)
		{
			printf("sceCameraStart failed 0x%x\n",result);
			return result;
		}
		s_started = 1;
		return result;
	}

	PRX_EXPORT int PrxCameraStop(int32_t handle)
	{
		s_started = 0;
		s_camera_handle = 0;
		return sceCameraStop(handle);
	}

  PRX_EXPORT void * PrxCameraGetFrameIntPtr(uint64_t framehandle, int device, int level)
  {
		SceCameraFrameData *curFrame = (SceCameraFrameData *)framehandle;
		void * rawData = curFrame->pFramePointerList[device][level];
		UNITY_TRACE("Camera get frame dev:%d lev:%d result:0x%p\n", device, level, rawData);
		return rawData;
  }

	PRX_EXPORT int PrxCameraGetFrameData(int handle, uint32_t readMode,  uint64_t * framehandle)
	{
		// TODO: proper buffer feeding
		if ((s_lastretreivedbuffer>=CAM_BUF_CNT)||(s_lastretreivedbuffer<0)) { return -1; }
		SceCameraFrameData *curFrame = &s_camFrame[s_lastretreivedbuffer];
		*framehandle = (uint64_t)curFrame;
		int result = 0;
		return result;
	}

	typedef unsigned char UInt8;

	struct ColorRGBA32
	{
		UInt8	r, g, b, a;
	};


void yuy2_bgra(unsigned char *dst, const unsigned char *src, const int width, const int height)
{
	int x, y;
	const int width2 = width * 2;
	const int width4 = width * 4;
	const unsigned char *src1 = src;
		  unsigned char *dst1 = dst;
	for (y=0; y<height; y++) {
		for (x=0; x<width; x+=2) {
			int x2=x*2;
			int y1  = src1[x2  ];
			int y2  = src1[x2+2];
			int u   = src1[x2+1] - 128;
			int v   = src1[x2+3] - 128;
			int uvr = (          15748 * v) / 10000;
			int uvg = (-1873 * u - 4681 * v) / 10000;
			int uvb = (18556 * u          ) / 10000;

			int x4=x*4;
			int r1 = y1 + uvr;
			int r2 = y2 + uvr;
			int g1 = y1 + uvg;
			int g2 = y2 + uvg;
			int b1 = y1 + uvb;
			int b2 = y2 + uvb;
			dst1[x4  ] = (b1 > 255) ? 255 : ((b1 < 0) ? 0 : b1);
			dst1[x4+1] = (g1 > 255) ? 255 : ((g1 < 0) ? 0 : g1);
			dst1[x4+2] = (r1 > 255) ? 255 : ((r1 < 0) ? 0 : r1);
			dst1[x4+3] = 255;
			dst1[x4+4] = (b2 > 255) ? 255 : ((b2 < 0) ? 0 : b2);
			dst1[x4+5] = (g2 > 255) ? 255 : ((g2 < 0) ? 0 : g2);
			dst1[x4+6] = (r2 > 255) ? 255 : ((r2 < 0) ? 0 : r2);
			dst1[x4+7] = 255;
		}
		src1 += width2;
		dst1 += width4;
	}
}

//
//	PRX_EXPORT void PrxGetPixels32(uint64_t  framehandle, ColorRGBA32* data)
//	{
//		SceCameraFrameData *curFrame = (SceCameraFrameData *) framehandle;
////		printf("getpixel 0x%x\n",data);
//		yuy2_bgra((unsigned char *)data, (unsigned char *)curFrame->pFramePointerList[0][0],1280,800);
//	}
//
//	
//	PRX_EXPORT void PrxGetPixels8(uint64_t  framehandle, unsigned char* data)
//	{
//		SceCameraFrameData *curFrame = (SceCameraFrameData *) framehandle;
////		printf("getpixel 0x%x\n",data);
//	//	memcpy(unsigned char *)data, (unsigned char *)curFrame->pFramePointerList[0][0],1280 *800 );
////		yuy2_bgra((unsigned char *)data, (unsigned char *)curFrame->pFramePointerList[0][0],1280,800);
//	}

	static void* cameraThread(void* ptr);

	PRX_EXPORT void PrxCameraInit(void)
	{
		UNITY_TRACE("PrxCameraInit\n");

		s_GameEnd = 0;
		int ret = scePthreadMutexInit(&s_thread_mutex, NULL, "cameraSampleRecvMutex");
		if (0 > ret) 
		{
			printf("scePthreadMutexInit() failed\n");
		}

		ScePthreadAttr attr;
		scePthreadAttrInit(&attr);
		scePthreadAttrSetinheritsched(&attr, SCE_PTHREAD_EXPLICIT_SCHED);
		scePthreadAttrSetaffinity(&attr, 0x3f);	// 0x3f = all cores

		ret = scePthreadCreate(&m_thread_camera, &attr, cameraThread, NULL, "cameraSampleRecvThread");
		if (0 > ret) 
		{
			printf("scePthreadCreate() failed\n");
		}


		scePthreadAttrDestroy(&attr);

		SceKernelSchedParam  schedparam;
		int policy;
		scePthreadGetschedparam(m_thread_camera, &policy, &schedparam);
		UNITY_TRACE("policy:%d prio:%d\n", policy, schedparam.sched_priority);

		schedparam.sched_priority = 700+1;

		scePthreadSetschedparam(m_thread_camera, policy, &schedparam);

		for (int i = 0; i < CAM_BUF_CNT; i++)
		{
			//ret = scePthreadMutexInit(&s_thread_draw_mutex[i], NULL, "cameraSampleDrawMutex");
	  //      if (0 > ret) {
			//	ERRP("scePthreadMutexInit() failed\n");
			//	return -1;
			//}

			ret = sceKernelCreateEventFlag(&s_event_flag[i], "cameraSampleEvent", SCE_KERNEL_EVF_ATTR_SINGLE | SCE_KERNEL_EVF_ATTR_TH_FIFO, 0x0, NULL );
			if (0 > ret) 
			{
				printf("sceKernelCreateEventFlag() failed\n");
				return;
			}

	/*		int *param = (int *)malloc(sizeof(int));
			*param = i;
			ret = scePthreadCreate(&m_thread_draw[i], NULL, drawCheckThread, (void *)param, "cameraSampleDrawCheckThread");
			if (0 > ret) {
				ERRP("scePthreadCreate() failed\n");
				return -1;
			}*/
		}
	}

	PRX_EXPORT void PrxCameraShutdown(void)
	{
		int ret;

		s_GameEnd = 1;	// trigger camera thread to exit at next loop

		// cancels thread and waits for exit 
		UNITY_TRACE("caling camera thread cancel\n");
		if (m_thread_camera != 0)
		{
			//ret = scePthreadCancel(m_thread_camera);
			//if (ret <0)
			//	printf("scePthreadCancel() failed 0x%x\n", ret);

			// wait for it to terminate
			UNITY_TRACE("camera scePthreadJoin() called\n");
			ret = scePthreadJoin(m_thread_camera, NULL);
			if (ret <0)
				printf("scePthreadJoin() failed 0x%x\n", ret);
		}

		UNITY_TRACE("camera thread canceled\n");

		// now the thread has closed we can now shut down the camera handle (as per sample code)
		if (s_camera_handle)
		{
			int cameraHandle = s_camera_handle;	// 
			UNITY_TRACE("calling camera stop\n");
			ret = PrxCameraStop(cameraHandle);	// stop the camera if it was running .. also clears s_camera_handle
			if (ret < 0)
				printf("PrxCameraStop() failed 0x%x\n", ret);

			UNITY_TRACE("calling camera close\n");
			ret = sceCameraClose(cameraHandle);
			if (ret < 0)
				printf("sceCameraClose() failed 0x%x\n", ret);
		}



		if (s_thread_mutex != 0)
		{
			ret = scePthreadMutexDestroy(&s_thread_mutex);
			if (ret <0)
				printf("scePthreadMutexDestroy() failed 0x%x\n", ret);
			s_thread_mutex = 0;
		}


		for (int i = 0; i < CAM_BUF_CNT; i++)
		{
			if (s_event_flag[i] != 0)
			{
				ret = sceKernelDeleteEventFlag(s_event_flag[i]);
				if (ret < 0)
					printf("sceKernelDeleteEventFlag() failed 0x%x\n", ret);
				s_event_flag[i] = 0;
			}
		}

		m_thread_camera = 0;
	}


	static uint32_t s_ExposureGain[2]=
	{
		SCE_CAMERA_ATTRIBUTE_EXPOSUREGAIN_MODE_0,
		SCE_CAMERA_ATTRIBUTE_EXPOSUREGAIN_MODE_0
	};

	PRX_EXPORT void PrxCameraSetExposureGainMode(int Camera0mode, int Camera1mode)
	{
		s_ExposureGain[0] = Camera0mode;
		s_ExposureGain[1] = Camera1mode;
	}

	static void* cameraThread(void* ptr)
	{

		int res = 0;
		SceKernelTimespec wait_time;
		int started = 0;
		int handle = 0;

		int buf_index = 0;
		UNITY_TRACE("cameraThread started\n");
		while(1)
		{
			if(s_GameEnd)
				break;
			
			UNITY_TRACE("cameraThread loop\n");

			scePthreadMutexLock(&s_thread_mutex);
			started = s_started;
			scePthreadMutexUnlock(&s_thread_mutex);

			if(started)
			{
				scePthreadMutexLock(&s_thread_mutex);
				handle = s_camera_handle;
				scePthreadMutexUnlock(&s_thread_mutex);

				wait_time.tv_sec = 0;
				wait_time.tv_nsec= 10000;//10ms
				s_camFrame[buf_index].sizeThis = sizeof(SceCameraFrameData);
				double gravity = 0;
				s_camFrame[buf_index].meta.exposureGain[0].mode = s_ExposureGain[0];
				s_camFrame[buf_index].meta.exposureGain[1].mode = s_ExposureGain[1];
				s_camFrame[buf_index].readMode = SCE_CAMERA_FRAME_MEMORY_TYPE_ONION | SCE_CAMERA_FRAME_WAIT_NEXTFRAME_ON;

//				sceKernelNanosleep(&wait_time, NULL);

				UNITY_TRACE("cameraThread get frame\n");

				res = sceCameraGetFrameData(s_camera_handle, &s_camFrame[buf_index]);
				if(res){
					if(res == SCE_CAMERA_ERROR_NOT_CONNECTED){
						printf("Camera is not connected.\n");
						wait_time.tv_sec = 1;
						sceKernelNanosleep(&wait_time, NULL);
						continue;
					}else{
						printf("sceCameraGetFrameData = %x\n", res);
					}
				}
				UNITY_TRACE("cameraThread get frame good\n");

				// fill area
		/*		int testvalue = 0x00ff0000;
				int *pVal =(int *)s_camFrame[buf_index].pFramePointerList[0][0];
				for (int y=0;y<100;y++)
				{
					int *pLine =pVal;
					pVal+=640;
					for (int x=0;x<100;x++)
						*(pLine++)=testvalue;
				}*/



				s_lastretreivedbuffer = buf_index;		// todo: replace with proper notification code
				sceKernelSetEventFlag(s_event_flag[buf_index], EVF_BIT_DRAW);
				
				if (CameraFrameCallback != NULL)
				{
					res = CameraFrameCallback(&s_camFrame[buf_index]);
				}

				buf_index ++;
				if (buf_index == CAM_BUF_CNT){
					buf_index = 0;
				}


#if 0
				//printf("sceCameraGetFrameData = %x time=%ld frame=%ld pts=%d\n", res, s_camFrame.meta.timestamp[0], s_camFrame.meta.frame[0], s_camFrame.meta.deviceTimestamp[0]);
				gravity = sqrt(pow(s_camFrame[buf_index].meta.acceleration.x, 2)+pow(s_camFrame[buf_index].meta.acceleration.y,2)+pow(s_camFrame[buf_index].meta.acceleration.z,2));

				if(gravity < 0.5 || gravity > 1.5)
					printf("acceleration over +- 0.5g. [1g:%1.8lf x:%1.10lf y:%1.8lf z:%1.8lf]\n", gravity, s_camFrame[buf_index].meta.acceleration.x, s_camFrame[buf_index].meta.acceleration.y, s_camFrame[buf_index].meta.acceleration.z);
#ifdef CAMERA_TIMESTAMP_DUMP
				//if(s_camFrame.meta.timestamp[0]-s_prevTime > 20000)
				printf("sceCameraGetFrameData = %x time=%ld frame=%ld pts=%d: diff=%ld\n", res, s_camFrame.meta.timestamp[0], s_camFrame.meta.frame[0], s_camFrame.meta.deviceTimestamp[0], s_camFrame.meta.timestamp[0]-s_prevTime);
				s_prevTime = s_camFrame.meta.timestamp[0];
#endif
				s_count++;
				if(s_camFrame[buf_index].meta.frame[0] % 500 == 0)
				{
				//printf("sceCameraGetFrameData = %x time=%ld frame=%ld pts=%d: diff=%ld\n", res, s_camFrame.meta.timestamp[0], s_camFrame.meta.frame[0], s_camFrame.meta.deviceTimestamp[0], s_camFrame.meta.timestamp[0]-s_prevTime);
#ifdef CAMERA_META_DATA_DUMP
					printf("FrameData = %08ld L(e:%03d g:%03d(%d) rgb:%04d %04d %04d l:%08d) R(e:%03d g:%03d(%d) rgb:%04d %04d %04d l:%08d)\n", s_camFrame[buf_index].meta.frame[0], 
						s_camFrame[buf_index].meta.exposureGain[0].exposure, s_camFrame[buf_index].meta.exposureGain[0].gain, s_camFrame[buf_index].meta.exposureGain[0].exposureControl,  
						s_camFrame[buf_index].meta.whiteBalance[0].gainRed, s_camFrame[buf_index].meta.whiteBalance[0].gainGreen, s_camFrame[buf_index].meta.whiteBalance[0].gainBlue, 
						s_camFrame[buf_index].meta.luminance[0], 
						s_camFrame[buf_index].meta.exposureGain[1].exposure, s_camFrame[buf_index].meta.exposureGain[1].gain, s_camFrame[buf_index].meta.exposureGain[1].exposureControl,
						s_camFrame[buf_index].meta.whiteBalance[1].gainRed, s_camFrame[buf_index].meta.whiteBalance[1].gainGreen, s_camFrame[buf_index].meta.whiteBalance[1].gainBlue, 
						s_camFrame[buf_index].meta.luminance[1]);
					printf("format[0]= %d %d %d %d(state:%d), [1]=%d %d %d %d(state:%d)\n", 
						s_camFrame[buf_index].meta.format[0][0], s_camFrame[buf_index].meta.format[0][1], s_camFrame[buf_index].meta.format[0][2], s_camFrame[buf_index].meta.format[0][3], s_camFrame[buf_index].status[0], 
						s_camFrame[buf_index].meta.format[1][0], s_camFrame[buf_index].meta.format[1][1], s_camFrame[buf_index].meta.format[1][2], s_camFrame[buf_index].meta.format[1][3], s_camFrame[buf_index].status[1]);
#endif
#ifdef CAMERA_FRAMEPTR_DUMP
					printf("pointer[0]= %p %p %p %p(s:%d), [1]=%p %p %p %p(s:%d)\n", 
						s_camFrame.pFramePointerList[0][0], s_camFrame.pFramePointerList[0][1], s_camFrame.pFramePointerList[0][2], s_camFrame.pFramePointerList[0][3], s_camFrame.status[0], 
						s_camFrame.pFramePointerList[1][0], s_camFrame.pFramePointerList[1][1], s_camFrame.pFramePointerList[1][2], s_camFrame.pFramePointerList[1][3], s_camFrame.status[1]);
#endif
				}
#endif
			}else{
				UNITY_TRACE("camera not started yet ... sleeping 1 second\n");
				sceKernelSleep(1);
			}
		}
		scePthreadExit(NULL);
	}





}