#ifndef _PRX_H
#define _PRX_H

#define PRX_EXPORT extern "C" __declspec (dllexport)
#include <stdlib.h>

#endif